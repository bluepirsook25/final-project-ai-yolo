# =============================================================================
#  LuxeSmile Dental — Mobile App  (Pydroid 3  +  Buildozer APK)
#
#  RUN INSTANTLY (Pydroid 3 on your phone):
#    1. Pydroid 3  ->  pip menu  ->  install:  pillow
#    2. Open this main.py  ->  tap  ▶ Run
#    3. Tap the link it prints, or open Chrome ->  http://localhost:8766
#       (tap  ⋮  ->  "Add to Home screen"  to get a LuxeSmile icon)
#
#  BUILD A REAL APP (.apk) with the LuxeSmile icon:
#    Put main.py + icon.png + presplash.png + buildozer.spec in one folder, then:
#       buildozer android debug
#    The .apk lands in  bin/  -> copy to phone -> install -> tap to open.
#
#  Features:  AI teeth scan (front/back camera toggle) · appointment booking
#             that auto-adds the reservation to your phone calendar.
# =============================================================================

import os, json, sqlite3, threading, socketserver, time, io, datetime
from http.server import BaseHTTPRequestHandler

PORT = 8766
socketserver.ThreadingTCPServer.allow_reuse_address = True


# ── On-device teeth analysis (Pillow only — no OpenCV) ──────────────────────
def analyse_image(image_bytes):
    """Colour + edge analysis of a teeth photo (same LAB-luminance logic as TeethAI)."""
    results, flags = [], []
    try:
        from PIL import Image, ImageFilter, ImageStat
        img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        w, h = img.size
        mx, my = int(w * 0.15), int(h * 0.25)
        roi = img.crop((mx, my, w - mx, h - my))
        rw, rh = roi.size

        edges = roi.convert('L').filter(ImageFilter.FIND_EDGES)
        edge_mean = ImageStat.Stat(edges).mean[0]
        edge_label = 'Sharp' if edge_mean > 18 else 'Moderate' if edge_mean > 9 else 'Soft'

        rs = ImageStat.Stat(roi).mean[:3]
        L = 0.299 * rs[0] + 0.587 * rs[1] + 0.114 * rs[2]
        yellow = (rs[0] + rs[1]) / 2 - rs[2]
        grade, gc = (('Excellent', '#16a34a') if L > 155 else
                     ('Good', '#0fb5a8') if L > 100 else
                     ('Fair', '#f59e0b') if L > 50 else ('Stained', '#ef4444'))

        tooth_w = max(1, rw // 8); detected = []
        for i in range(8):
            x1, x2 = i * tooth_w, min((i + 1) * tooth_w, rw)
            ps = ImageStat.Stat(roi.crop((x1, 0, x2, rh))).mean
            pL = 0.299 * ps[0] + 0.587 * ps[1] + 0.114 * ps[2]
            if pL < 30:
                continue
            pY = (ps[0] + ps[1]) / 2 - ps[2]
            pg = 'Stained' if pY > 40 else 'Excellent' if pL > 155 else 'Good' if pL > 100 else 'Fair'
            detected.append({'tooth': i + 1, 'conf': round(min(0.99, max(0.40, pL / 255 * 1.3)), 2),
                             'grade': pg, 'L': round(pL, 1)})

        if not detected:
            flags.append('No_Teeth_Detected')
        elif len(detected) < 4:
            flags.append('Few_Teeth_Visible — open mouth wider')
        if yellow > 45:
            flags.append('Staining_Detected — whitening recommended')

        gmap = {'Excellent': '#16a34a', 'Good': '#0fb5a8', 'Fair': '#f59e0b', 'Stained': '#ef4444'}
        results = [{'label': f"Tooth {d['tooth']}", 'conf': d['conf'], 'grade': d['grade'],
                    'color': gmap.get(d['grade'], '#94a3b8')} for d in detected]
        results.insert(0, {'label': f"Overall: {grade}", 'conf': round(L / 255, 2), 'grade': grade,
                           'color': gc, 'edge': edge_label, 'tooth_count': len(detected),
                           'luminance': round(L, 1), 'yellowness': round(yellow, 1), 'is_summary': True})
    except Exception as e:
        flags.append(f'Analysis_Error: {e}')
        results = [{'label': 'Error during analysis', 'conf': 0, 'grade': 'Unknown',
                    'color': '#ef4444', 'is_summary': True}]
    return results, flags


# ── HTML / CSS / JS (LuxeSmile light theme, matching the v31 website) ───────
HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="theme-color" content="#0fb5a8"/>
<title>LuxeSmile</title>
<link rel="manifest" href="/manifest.json"/>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<style>
:root{--bg:#f6f9fc;--surface:#eef3f8;--card:#ffffff;--border:#e4e9f0;--teal:#0fb5a8;--teal2:#0d9488;--violet:#7c3aed;--amber:#f59e0b;--pink:#ec4899;--text:#13293f;--muted:#64748b}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;padding-bottom:84px}
header{background:rgba(255,255,255,.95);backdrop-filter:blur(8px);border-bottom:1px solid var(--border);padding:13px 18px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.logo{font-family:'Syne',sans-serif;font-weight:800;font-size:1.15rem;color:var(--text)}.logo span{color:var(--teal)}
.tag{font-size:.65rem;color:var(--muted);background:rgba(15,181,168,.1);padding:3px 9px;border-radius:20px;border:1px solid rgba(15,181,168,.25)}
main{padding:14px;max-width:520px;margin:0 auto}
.sec{display:none}.sec.active{display:block;animation:fi .2s ease}
@keyframes fi{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.card-shadow{box-shadow:0 1px 2px rgba(16,42,67,.05),0 10px 30px rgba(16,42,67,.06)}
.hero{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:20px;margin-bottom:12px;position:relative;overflow:hidden;box-shadow:0 1px 2px rgba(16,42,67,.05),0 10px 30px rgba(16,42,67,.06)}
.hero::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--teal),var(--violet),var(--amber))}
.ht{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;color:var(--text);margin-bottom:5px;line-height:1.15}
.ht .g{color:var(--teal)}
.hs{font-size:.85rem;color:var(--muted);line-height:1.6;margin-bottom:16px}
.sr{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px}
.st{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:12px;text-align:center}
.sn{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;display:block}
.sl{font-size:.6rem;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
.btn{display:block;width:100%;padding:13px;border:none;border-radius:12px;font-size:.9rem;font-weight:700;cursor:pointer;font-family:'DM Sans',sans-serif;margin-bottom:8px;text-align:center;transition:.15s}
.btn-t{background:var(--teal);color:#fff}.btn-o{background:#fff;color:var(--text);border:1px solid var(--border)}
.btn-v{background:var(--violet);color:#fff}.btn-g{background:#fff;color:var(--teal);border:1px solid rgba(15,181,168,.5)}
.btn:active{opacity:.82;transform:scale(.99)}
.sec-title{font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:800;color:var(--text);margin-bottom:12px}
/* Camera */
.cam-wrap{background:#0b1f33;border:2px dashed rgba(15,181,168,.4);border-radius:18px;overflow:hidden;margin-bottom:10px;position:relative;min-height:230px;display:flex;align-items:center;justify-content:center}
#vid{width:100%;display:none;max-height:320px;object-fit:cover}
#canvas{display:none}
.cam-ph{text-align:center;padding:34px 20px;color:#cfe0ff}
.cam-ph .icon{font-size:2.8rem;display:block;margin-bottom:8px}
.cam-ph p{font-size:.8rem;opacity:.8}
.cam-badge{position:absolute;top:10px;right:10px;background:rgba(0,0,0,.55);color:#fff;font-size:.62rem;padding:4px 9px;border-radius:20px;display:none}
.cam-badge.on{display:block}
.scanl{position:absolute;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--teal),transparent);animation:scan 2s linear infinite;display:none}
.scanl.on{display:block}@keyframes scan{0%{top:0}100%{top:100%}}
#snap-preview{width:100%;border-radius:14px;display:none;margin-bottom:10px;border:2px solid var(--teal)}
.cam-ctrl{display:flex;gap:8px;margin-bottom:8px}.cam-ctrl .btn{flex:1;margin:0}
/* Results */
.result-wrap{background:rgba(15,181,168,.06);border:1px solid rgba(15,181,168,.25);border-radius:14px;padding:14px;margin-bottom:10px;display:none}
.result-wrap.show{display:block}
.result-title{font-size:.82rem;color:var(--teal2);font-weight:700;margin-bottom:10px}
.r-summary{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:10px}
.r-sum-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:7px}
.r-sum-row:last-child{margin:0}
.r-label{font-size:.78rem;color:var(--muted)}.r-val{font-size:.85rem;font-weight:700}
.r-grade{font-size:1rem;font-weight:800;font-family:'Syne',sans-serif}
.tooth-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px}
.tooth-card{background:var(--card);border:1px solid var(--border);border-radius:8px;padding:8px 4px;text-align:center}
.tooth-num{font-size:.65rem;color:var(--muted);display:block}
.tooth-g{font-size:.7rem;font-weight:700;display:block;margin-top:2px}
.tooth-c{font-size:.6rem;color:var(--muted);display:block}
.flag-wrap{background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:10px 12px;margin-bottom:10px;display:none}
.flag-wrap.show{display:block}
.flag-item{font-size:.78rem;color:#b91c1c;margin-bottom:3px}.flag-item:last-child{margin:0}
/* Forms / lists */
.fc{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;margin-bottom:12px;box-shadow:0 1px 2px rgba(16,42,67,.05),0 10px 30px rgba(16,42,67,.06)}
.fc h3{font-size:.9rem;font-weight:700;color:var(--text);margin-bottom:12px}
.fg{margin-bottom:11px}
.fl{font-size:.68rem;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;display:block;margin-bottom:4px}
.fi,.fs{width:100%;padding:11px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;color:var(--text);font-size:.88rem;font-family:'DM Sans',sans-serif;outline:none}
.fi:focus,.fs:focus{border-color:var(--teal);background:#fff}.fs option{background:#fff}
.clist{display:flex;flex-direction:column;gap:8px}
.item{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px}
.in{font-size:.88rem;font-weight:700;color:var(--text)}.im{font-size:.7rem;color:var(--muted);margin-top:2px}
.bdg{font-size:.65rem;padding:2px 8px;border-radius:20px;margin-top:4px;display:inline-block;background:rgba(245,158,11,.12);color:#b45309;border:1px solid rgba(245,158,11,.3)}
.item-actions{display:flex;flex-direction:column;gap:4px;align-items:flex-end}
.mini{font-size:.62rem;padding:5px 9px;border-radius:8px;border:1px solid rgba(15,181,168,.5);background:#fff;color:var(--teal);cursor:pointer;white-space:nowrap}
.del{background:none;border:none;color:#ef4444;cursor:pointer;font-size:1rem;padding:4px 6px}
/* Services / Doctors */
.svc{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px;margin-bottom:8px;display:flex;align-items:center;gap:12px;cursor:pointer;transition:.15s}
.svc:active{border-color:var(--teal)}
.svc .ic{width:44px;height:44px;border-radius:12px;background:var(--surface);display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0}
.svc .nm{font-weight:700;font-size:.88rem;color:var(--text)}
.svc .dsc{font-size:.7rem;color:var(--muted);margin-top:2px;line-height:1.4}
.svc .pr{font-size:.72rem;color:var(--teal2);font-weight:700;margin-top:3px}
.dc{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px;display:flex;align-items:center;gap:12px;margin-bottom:8px;cursor:pointer}
.dc:active{border-color:var(--teal)}
.dav{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.35rem;flex-shrink:0}
.dn{font-weight:700;font-size:.87rem;color:var(--text)}.ds{font-size:.7rem;color:var(--muted);margin-top:2px}.drt{font-size:.68rem;color:#b45309;margin-top:2px}
/* Contact */
.cc{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;margin-bottom:10px}
.cr{display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid var(--border)}
.cr:last-child{border:none;margin:0;padding:0}
.ci2{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:.95rem;flex-shrink:0}
.ct{font-size:.78rem;font-weight:700;color:var(--text)}.cv{font-size:.72rem;color:var(--muted);margin-top:1px;line-height:1.5}
/* Nav */
.bn{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,.97);backdrop-filter:blur(8px);border-top:1px solid var(--border);display:flex;padding:5px 0;z-index:100}
.tab{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:7px 2px;background:none;border:none;color:var(--muted);cursor:pointer;font-family:'DM Sans',sans-serif;font-size:.56rem;text-transform:uppercase;letter-spacing:.3px}
.tab.active{color:var(--teal)}.ti{font-size:1.1rem}
.toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(10px);background:var(--text);color:#fff;padding:10px 20px;border-radius:50px;font-size:.8rem;font-weight:600;z-index:999;opacity:0;transition:.3s;pointer-events:none;white-space:nowrap;box-shadow:0 8px 24px rgba(16,42,67,.25)}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.spinner{display:inline-block;width:16px;height:16px;border:2px solid rgba(15,181,168,.3);border-top-color:var(--teal);border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle;margin-right:6px}
@keyframes spin{to{transform:rotate(360deg)}}
.cal-box{background:rgba(124,58,237,.06);border:1px solid rgba(124,58,237,.25);border-radius:12px;padding:12px;margin-top:8px;display:none}
.cal-box.show{display:block}
.cal-box .ct2{font-size:.78rem;font-weight:700;color:var(--violet);margin-bottom:8px}
</style>
</head>
<body>
<header>
  <div class="logo">Luxe<span>Smile</span></div>
  <div class="tag">AI Dental · Brussels</div>
</header>
<main>

<!-- HOME -->
<div id="s-home" class="sec active">
  <div class="hero">
    <div class="ht">A healthier, <span class="g">brighter smile</span> 🦷</div>
    <div class="hs">Scan your teeth with AI, then book an appointment — it's added straight to your phone calendar.</div>
    <div class="sr">
      <div class="st"><span class="sn" style="color:var(--teal)" id="sa">0</span><span class="sl">Bookings</span></div>
      <div class="st"><span class="sn" style="color:var(--amber)">5</span><span class="sl">Doctors</span></div>
      <div class="st"><span class="sn" style="color:var(--violet)" id="ss">0</span><span class="sl">Scans</span></div>
    </div>
    <button class="btn btn-t" onclick="go('scan')">📷 Scan My Teeth</button>
    <button class="btn btn-o" onclick="go('book')">📅 Book Appointment</button>
  </div>
  <div class="sec-title">Popular services</div>
  <div id="home-svc"></div>
</div>

<!-- SCAN -->
<div id="s-scan" class="sec">
  <div class="sec-title">🔬 Teeth Scan &amp; Analysis</div>
  <div class="cam-wrap" id="cam-wrap">
    <div class="scanl" id="scanl"></div>
    <div class="cam-badge" id="cam-badge">Back camera</div>
    <video id="vid" autoplay playsinline muted></video>
    <div class="cam-ph" id="cam-ph">
      <span class="icon">📷</span>
      <p>Tap "Start Camera" below<br>Open mouth, keep steady</p>
    </div>
  </div>
  <img id="snap-preview" alt="captured"/>
  <canvas id="canvas"></canvas>
  <div class="cam-ctrl">
    <button class="btn btn-t" id="btn-cam" onclick="toggleCam()">Start Camera</button>
    <button class="btn btn-o" id="btn-flip" onclick="flipCam()" style="display:none;max-width:56px;padding:13px 8px">🔄</button>
  </div>
  <button class="btn btn-v" id="btn-snap" onclick="takeSnap()" style="display:none">📸 Take Photo</button>
  <button class="btn btn-t" id="btn-analyse" onclick="analyseSnap()" style="display:none">🔍 Analyse with AI</button>
  <button class="btn btn-o" id="btn-retake" onclick="retake()" style="display:none">↩ Retake Photo</button>
  <div class="flag-wrap" id="flag-wrap"></div>
  <div class="result-wrap" id="result-wrap">
    <div class="result-title">🦷 Analysis Results</div>
    <div class="r-summary" id="r-summary"></div>
    <div class="tooth-grid" id="tooth-grid"></div>
    <button class="btn btn-t" onclick="goBook()">📅 Book Appointment Now</button>
  </div>
</div>

<!-- BOOK -->
<div id="s-book" class="sec">
  <div class="sec-title">Book Appointment</div>
  <div class="fc"><h3>New Appointment</h3>
    <div class="fg"><label class="fl">Doctor</label><select class="fs" id="ad"></select></div>
    <div class="fg"><label class="fl">Your Name</label><input class="fi" id="an" placeholder="Full name"/></div>
    <div class="fg" id="scan-note-wrap" style="display:none">
      <label class="fl">Scan Result</label>
      <div class="fi" id="scan-note" style="font-size:.75rem;color:var(--teal2)"></div>
    </div>
    <div class="fg"><label class="fl">Date</label><input class="fi" id="adate" type="date"/></div>
    <div class="fg"><label class="fl">Time</label>
      <select class="fs" id="at">
        <option>09:00</option><option>09:30</option><option>10:00</option><option>10:30</option>
        <option>11:00</option><option>11:30</option><option>14:00</option><option>14:30</option>
        <option>15:00</option><option>15:30</option><option>16:00</option>
      </select></div>
    <div class="fg"><label class="fl">Service</label><select class="fs" id="av"></select></div>
    <button class="btn btn-t" onclick="book()">Confirm Booking</button>
    <div class="cal-box" id="cal-box">
      <div class="ct2">✓ Booked! Add it to your phone calendar:</div>
      <button class="btn btn-v" id="cal-gcal">📅 Add to Google Calendar</button>
      <button class="btn btn-g" id="cal-ics">⬇ Add via .ics (any calendar)</button>
    </div>
  </div>
  <div class="sec-title">My Appointments</div>
  <div class="clist" id="alist"></div>
</div>

<!-- SERVICES -->
<div id="s-services" class="sec">
  <div class="sec-title">Our Services</div>
  <div id="svclist"></div>
</div>

<!-- DOCTORS -->
<div id="s-doctors" class="sec">
  <div class="sec-title">Our Specialists</div>
  <div id="dlist"></div>
</div>

<!-- CONTACT -->
<div id="s-contact" class="sec">
  <div class="sec-title">Contact</div>
  <div class="cc">
    <div class="cr"><div class="ci2" style="background:rgba(15,181,168,.1)">📍</div><div><div class="ct">Address</div><div class="cv">Rue de la Loi 42, 1000 Brussels</div></div></div>
    <div class="cr"><div class="ci2" style="background:rgba(245,158,11,.1)">📞</div><div><div class="ct">Phone</div><div class="cv">+32 2 555 0199</div></div></div>
    <div class="cr"><div class="ci2" style="background:rgba(124,58,237,.1)">✉️</div><div><div class="ct">Email</div><div class="cv">contact@luxesmile.be</div></div></div>
    <div class="cr"><div class="ci2" style="background:rgba(236,72,153,.1)">🕐</div><div><div class="ct">Hours</div><div class="cv">Mon–Fri 08:00–19:00 · Sat 09:00–13:00</div></div></div>
  </div>
</div>

</main>
<nav class="bn">
  <button class="tab active" onclick="go('home')"><span class="ti">🏠</span>Home</button>
  <button class="tab" onclick="go('scan')"><span class="ti">📷</span>Scan</button>
  <button class="tab" onclick="go('book')"><span class="ti">📅</span>Book</button>
  <button class="tab" onclick="go('services')"><span class="ti">🦷</span>Services</button>
  <button class="tab" onclick="go('doctors')"><span class="ti">👨‍⚕️</span>Doctors</button>
  <button class="tab" onclick="go('contact')"><span class="ti">📍</span>Contact</button>
</nav>
<div class="toast" id="tst"></div>

<script>
const TABS = ['home','scan','book','services','doctors','contact'];
const CLINIC = {name:'LuxeSmile Dental', loc:'Rue de la Loi 42, 1000 Brussels'};
const DOCS = [
  {id:1,n:'Dr. Sarah Mitchell',s:'General Dentistry',e:'👩‍⚕️',r:'4.9★',bg:'rgba(15,181,168,.12)'},
  {id:2,n:'Dr. James Okonkwo',s:'Orthodontics',e:'👨‍⚕️',r:'4.8★',bg:'rgba(124,58,237,.12)'},
  {id:3,n:'Dr. Elena Vasquez',s:'Cosmetic Dentistry',e:'👩‍⚕️',r:'5.0★',bg:'rgba(245,158,11,.12)'},
  {id:4,n:'Dr. Kai Nakamura',s:'Oral Surgery',e:'🧑‍⚕️',r:'4.9★',bg:'rgba(56,189,248,.12)'},
  {id:5,n:'Dr. Priya Sharma',s:'Paediatric Dentistry',e:'👩‍⚕️',r:'4.8★',bg:'rgba(236,72,153,.12)'},
];
const SERVICES = [
  {n:'General Dentistry',d:'Check-ups, cleanings, fillings and preventive care.',p:'€40 – €150',ic:'🦷'},
  {n:'Dental Implants',d:'Permanent titanium replacements for missing teeth.',p:'€1,200 – €2,500',ic:'🦾'},
  {n:'Orthodontics',d:'Braces and aligners to straighten teeth and correct the bite.',p:'€2,000 – €5,000',ic:'😬'},
  {n:'Invisalign',d:'Clear, removable aligners — straighten discreetly.',p:'€2,500 – €5,500',ic:'🪥'},
  {n:'Cosmetic Dentistry',d:'Smile makeovers tailored to your face and goals.',p:'From €250',ic:'✨'},
  {n:'Teeth Whitening',d:'Safe in-clinic and take-home whitening.',p:'€250 – €450',ic:'💎'},
  {n:'Veneers',d:'Thin porcelain shells for a flawless front-tooth look.',p:'€600 – €1,100',ic:'🪞'},
  {n:'Root Canal Treatment',d:'Save an infected tooth and relieve pain.',p:'€300 – €700',ic:'🩺'},
  {n:'Paediatric Dentistry',d:'Gentle, friendly dental care for children.',p:'€30 – €120',ic:'🧒'},
  {n:'Emergency Dental Care',d:'Same-day relief for pain, swelling and trauma.',p:'From €80',ic:'🚑'},
];

let lastScanSummary = '';
let lastAppt = null;

function go(id){
  document.querySelectorAll('.sec').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('s-'+id).classList.add('active');
  const idx = TABS.indexOf(id);
  if(idx>=0) document.querySelectorAll('.tab')[idx].classList.add('active');
  if(id==='doctors') rDocs();
  if(id==='services') rServices();
  if(id==='book'){ lAppts(); const dd=document.getElementById('adate'); if(!dd.value) dd.valueAsDate=new Date(); }
  window.scrollTo(0,0);
}

// ── Camera (front / back toggle) ───────────────────────────────────────────
let stream=null, camOn=false, facingMode='environment', snapBlob=null;
async function toggleCam(){ if(camOn) stopCam(); else await startCam(); }
async function startCam(){
  try{
    if(stream){ stream.getTracks().forEach(t=>t.stop()); stream=null; }
    stream = await navigator.mediaDevices.getUserMedia({
      video:{ facingMode:{ideal:facingMode}, width:{ideal:1280}, height:{ideal:720} }, audio:false });
    const vid=document.getElementById('vid');
    vid.srcObject=stream; vid.style.display='block';
    document.getElementById('cam-ph').style.display='none';
    document.getElementById('scanl').classList.add('on');
    const badge=document.getElementById('cam-badge');
    badge.textContent = facingMode==='user' ? 'Front camera' : 'Back camera'; badge.classList.add('on');
    document.getElementById('btn-cam').textContent='Stop Camera';
    document.getElementById('btn-flip').style.display='block';
    document.getElementById('btn-snap').style.display='block';
    document.getElementById('btn-analyse').style.display='none';
    document.getElementById('btn-retake').style.display='none';
    document.getElementById('snap-preview').style.display='none';
    camOn=true;
  }catch(e){ toast('Camera error: '+e.message,'e'); }
}
function stopCam(){
  if(stream) stream.getTracks().forEach(t=>t.stop());
  stream=null; camOn=false;
  document.getElementById('vid').style.display='none';
  document.getElementById('cam-ph').style.display='block';
  document.getElementById('scanl').classList.remove('on');
  document.getElementById('cam-badge').classList.remove('on');
  document.getElementById('btn-cam').textContent='Start Camera';
  document.getElementById('btn-flip').style.display='none';
  document.getElementById('btn-snap').style.display='none';
}
async function flipCam(){
  facingMode = (facingMode==='environment') ? 'user' : 'environment';
  if(camOn) await startCam();
  toast(facingMode==='user' ? 'Front camera' : 'Back camera');
}
function takeSnap(){
  const vid=document.getElementById('vid'), can=document.getElementById('canvas');
  can.width=vid.videoWidth||640; can.height=vid.videoHeight||480;
  can.getContext('2d').drawImage(vid,0,0);
  can.toBlob(blob=>{
    snapBlob=blob;
    const prev=document.getElementById('snap-preview');
    prev.src=URL.createObjectURL(blob); prev.style.display='block';
    stopCam();
    document.getElementById('btn-snap').style.display='none';
    document.getElementById('btn-analyse').style.display='block';
    document.getElementById('btn-retake').style.display='block';
    toast('Photo taken — tap Analyse!');
  },'image/jpeg',0.92);
}
function retake(){
  snapBlob=null;
  document.getElementById('snap-preview').style.display='none';
  document.getElementById('btn-analyse').style.display='none';
  document.getElementById('btn-retake').style.display='none';
  document.getElementById('result-wrap').classList.remove('show');
  document.getElementById('flag-wrap').classList.remove('show');
  startCam();
}
function analyseSnap(){
  if(!snapBlob){ toast('Take a photo first','e'); return; }
  const btn=document.getElementById('btn-analyse');
  btn.innerHTML='<span class="spinner"></span>Analysing...'; btn.disabled=true;
  const img=new Image();
  img.onload=()=>{
    try{
      const can=document.createElement('canvas'), w=img.naturalWidth, h=img.naturalHeight;
      can.width=w; can.height=h; const ctx=can.getContext('2d'); ctx.drawImage(img,0,0);
      const mx=Math.floor(w*0.15), my=Math.floor(h*0.25), rw=w-2*mx, rh=h-2*my;
      const px=ctx.getImageData(mx,my,rw,rh).data;
      let rS=0,gS=0,bS=0,n=px.length/4;
      for(let i=0;i<px.length;i+=4){ rS+=px[i]; gS+=px[i+1]; bS+=px[i+2]; }
      const rM=rS/n,gM=gS/n,bM=bS/n, L=0.299*rM+0.587*gM+0.114*bM, yellow=(rM+gM)/2-bM;
      let eS=0,eN=0;
      for(let y=1;y<rh-1;y++)for(let x=1;x<rw-1;x++){
        const lum=v=>0.299*px[v]+0.587*px[v+1]+0.114*px[v+2];
        const gx=lum((y*rw+x+1)*4)-lum((y*rw+x-1)*4), gy=lum(((y+1)*rw+x)*4)-lum(((y-1)*rw+x)*4);
        eS+=Math.sqrt(gx*gx+gy*gy); eN++;
      }
      const eM=eS/eN, edgeLabel=eM>18?'Sharp':eM>9?'Moderate':'Soft';
      const grade=L>155?'Excellent':L>100?'Good':L>50?'Fair':'Stained';
      const gradeColor={Excellent:'#16a34a',Good:'#0fb5a8',Fair:'#f59e0b',Stained:'#ef4444'}[grade];
      const tw=Math.max(1,Math.floor(rw/8)), detected=[];
      for(let i=0;i<8;i++){
        const x1=i*tw,x2=Math.min((i+1)*tw,rw); let pr=0,pg=0,pb=0,pn=0;
        for(let y=0;y<rh;y++)for(let x=x1;x<x2;x++){ const idx=(y*rw+x)*4; pr+=px[idx];pg+=px[idx+1];pb+=px[idx+2];pn++; }
        const pR=pr/pn,pG=pg/pn,pB=pb/pn,pL=0.299*pR+0.587*pG+0.114*pB;
        if(pL<30) continue;
        const pY=(pR+pG)/2-pB, pg2=pY>40?'Stained':pL>155?'Excellent':pL>100?'Good':'Fair';
        detected.push({tooth:i+1,conf:Math.round(Math.min(0.99,Math.max(0.40,pL/255*1.3))*100)/100,grade:pg2});
      }
      const flags=[];
      if(detected.length===0) flags.push('No_Teeth_Detected');
      else if(detected.length<4) flags.push('Few_Teeth_Visible — open mouth wider');
      if(yellow>45) flags.push('Staining_Detected — whitening recommended');
      const gmap={Excellent:'#16a34a',Good:'#0fb5a8',Fair:'#f59e0b',Stained:'#ef4444'};
      const results=[{label:`Overall: ${grade}`,grade,color:gradeColor,edge:edgeLabel,tooth_count:detected.length,
        luminance:Math.round(L*10)/10,yellowness:Math.round(yellow*10)/10,is_summary:true},
        ...detected.map(d=>({label:`Tooth ${d.tooth}`,conf:d.conf,grade:d.grade,color:gmap[d.grade]||'#94a3b8'}))];
      showResults(results,flags);
      const sc=parseInt(document.getElementById('ss').textContent||'0'); document.getElementById('ss').textContent=sc+1;
    }catch(e){ toast('Analysis error: '+e.message,'e'); }
    btn.innerHTML='🔍 Analyse with AI'; btn.disabled=false;
  };
  img.onerror=()=>{ toast('Could not load image','e'); btn.innerHTML='🔍 Analyse with AI'; btn.disabled=false; };
  img.src=URL.createObjectURL(snapBlob);
}
function showResults(results,flags){
  const fw=document.getElementById('flag-wrap');
  if(flags&&flags.length){ fw.innerHTML=flags.map(f=>`<div class="flag-item">⚠ ${f}</div>`).join(''); fw.classList.add('show'); }
  else fw.classList.remove('show');
  const summary=results.find(r=>r.is_summary)||results[0];
  if(summary){
    lastScanSummary=`${summary.label} · Edge: ${summary.edge||'—'} · Teeth: ${summary.tooth_count||'—'}`;
    document.getElementById('r-summary').innerHTML=`
      <div class="r-sum-row"><span class="r-label">Overall Grade</span><span class="r-grade" style="color:${summary.color}">${summary.grade}</span></div>
      <div class="r-sum-row"><span class="r-label">Brightness (L)</span><span class="r-val">${summary.luminance||'—'}</span></div>
      <div class="r-sum-row"><span class="r-label">Edge Detail</span><span class="r-val" style="color:var(--teal2)">${summary.edge||'—'}</span></div>
      <div class="r-sum-row"><span class="r-label">Yellowness</span><span class="r-val" style="color:${(summary.yellowness||0)>40?'#ef4444':'#16a34a'}">${summary.yellowness||'—'}</span></div>
      <div class="r-sum-row"><span class="r-label">Teeth Detected</span><span class="r-val">${summary.tooth_count||'—'}</span></div>`;
  }
  const teeth=results.filter(r=>!r.is_summary);
  document.getElementById('tooth-grid').innerHTML=teeth.map(t=>`
    <div class="tooth-card"><span class="tooth-num">${t.label}</span>
      <span class="tooth-g" style="color:${t.color}">${t.grade}</span>
      <span class="tooth-c">${Math.round((t.conf||0)*100)}%</span></div>`).join('');
  document.getElementById('result-wrap').classList.add('show');
}
function goBook(){
  if(lastScanSummary){
    document.getElementById('scan-note').textContent=lastScanSummary;
    document.getElementById('scan-note-wrap').style.display='block';
    const sel=document.getElementById('av');
    if(lastScanSummary.includes('Stained')) sel.value='Teeth Whitening';
    else if(lastScanSummary.includes('Fair')) sel.value='General Dentistry';
    else sel.value='General Dentistry';
  }
  go('book');
}

// ── Services & Doctors ─────────────────────────────────────────────────────
function svcCard(s,onclick){
  return `<div class="svc" onclick="${onclick}"><div class="ic">${s.ic}</div>
    <div style="flex:1"><div class="nm">${s.n}</div><div class="dsc">${s.d}</div><div class="pr">${s.p}</div></div>
    <div style="color:var(--teal);font-size:1.1rem">›</div></div>`;
}
function rServices(){ document.getElementById('svclist').innerHTML=SERVICES.map(s=>svcCard(s,`pickService('${s.n.replace(/'/g,"")}')`)).join(''); }
function pickService(name){ go('book'); const sel=document.getElementById('av'); for(const o of sel.options) if(o.value===name) sel.value=name; toast('Selected: '+name); }
function rDocs(){
  document.getElementById('dlist').innerHTML=DOCS.map(d=>`
    <div class="dc" onclick="pickDoc(${d.id},'${d.n}')">
      <div class="dav" style="background:${d.bg}">${d.e}</div>
      <div style="flex:1"><div class="dn">${d.n}</div><div class="ds">${d.s}</div><div class="drt">${d.r}</div></div>
      <div style="color:var(--teal);font-size:1.1rem">›</div></div>`).join('');
}
function pickDoc(id,n){ go('book'); document.getElementById('ad').value=id; toast('Booking with '+n); }

// ── Calendar helpers (auto add reservation to phone calendar) ──────────────
function pad(n){return String(n).padStart(2,'0')}
function fmtLocal(dt){return `${dt.getFullYear()}${pad(dt.getMonth()+1)}${pad(dt.getDate())}T${pad(dt.getHours())}${pad(dt.getMinutes())}00`}
function startEnd(dateStr,timeStr){
  const s=new Date(`${dateStr}T${timeStr}:00`); const e=new Date(s.getTime()+60*60000);
  return [fmtLocal(s),fmtLocal(e)];
}
function gcalURL(a){
  const [s,e]=startEnd(a.d,a.t);
  const q=new URLSearchParams({action:'TEMPLATE',text:`LuxeSmile — ${a.v}`,dates:`${s}/${e}`,
    details:`Doctor: ${a.doc}${a.note?' · '+a.note:''} · Booked via LuxeSmile app`,location:CLINIC.loc});
  return 'https://calendar.google.com/calendar/render?'+q.toString();
}
function buildICS(a){
  const [s,e]=startEnd(a.d,a.t);
  const uid='luxesmile-'+(a.id||Date.now())+'@luxesmile.be';
  return ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//LuxeSmile//Dental App//EN','CALSCALE:GREGORIAN','METHOD:PUBLISH',
    'BEGIN:VEVENT','UID:'+uid,'DTSTAMP:'+s,'DTSTART:'+s,'DTEND:'+e,
    'SUMMARY:LuxeSmile — '+a.v,'DESCRIPTION:Doctor: '+a.doc+(a.note?' - '+a.note:'')+' (LuxeSmile app)',
    'LOCATION:'+CLINIC.loc.replace(/,/g,'\\,'),
    'BEGIN:VALARM','TRIGGER:-PT2H','ACTION:DISPLAY','DESCRIPTION:LuxeSmile appointment','END:VALARM',
    'END:VEVENT','END:VCALENDAR'].join('\r\n');
}
function downloadICS(a){
  const blob=new Blob([buildICS(a)],{type:'text/calendar;charset=utf-8'});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a'); link.href=url; link.download='luxesmile-appointment.ics';
  document.body.appendChild(link); link.click(); link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),5000);
  toast('Calendar file ready — open it to add');
}
function openGcal(a){ window.open(gcalURL(a),'_blank'); }

// ── Appointments (persist locally + server) ────────────────────────────────
function gA(){try{return JSON.parse(localStorage.getItem('ls_v31')||'[]')}catch{return[]}}
function sA(a){localStorage.setItem('ls_v31',JSON.stringify(a))}
function uSt(){document.getElementById('sa').textContent=gA().length}

function book(){
  const n=document.getElementById('an').value.trim();
  const d=document.getElementById('adate').value;
  const t=document.getElementById('at').value;
  const v=document.getElementById('av').value;
  const doc=DOCS[document.getElementById('ad').selectedIndex];
  const note=document.getElementById('scan-note').textContent||'';
  if(!n){toast('Enter your name','e');return}
  if(!d){toast('Pick a date','e');return}
  const appt={id:Date.now(),n,d,t,v,doc:doc.n,note};
  const a=gA(); a.unshift(appt); sA(a); uSt(); lAppts();
  lastAppt=appt;
  toast('Booked ✓ Adding to calendar…');
  // Auto-add to phone calendar (user gesture -> popup allowed). Google Calendar opens prefilled.
  openGcal(appt);
  // Reveal the calendar buttons (for .ics / Samsung / re-add)
  const cb=document.getElementById('cal-box'); cb.classList.add('show');
  document.getElementById('cal-gcal').onclick=()=>openGcal(appt);
  document.getElementById('cal-ics').onclick=()=>downloadICS(appt);
  // Save on the server (SQLite) in the background
  fetch('/api/book',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:n,date:d,time:t,service:v,doctor:doc.n,note})}).catch(()=>{});
}
function lAppts(){
  const a=gA();
  document.getElementById('alist').innerHTML = a.length ? a.map(x=>`
    <div class="item">
      <div style="flex:1">
        <div class="in">${x.n}</div>
        <div class="im">${x.d} ${x.t} · ${x.doc.split(' ').slice(0,2).join(' ')}</div>
        ${x.note?`<div class="im" style="color:var(--teal2)">${x.note}</div>`:''}
        <span class="bdg">${x.v}</span>
      </div>
      <div class="item-actions">
        <button class="mini" onclick='openGcal(${JSON.stringify(x)})'>📅 Calendar</button>
        <button class="mini" onclick='downloadICS(${JSON.stringify(x)})'>⬇ .ics</button>
        <button class="del" onclick="dA(${x.id})">🗑</button>
      </div>
    </div>`).join('')
    : '<div style="text-align:center;color:var(--muted);padding:20px;font-size:.82rem">No appointments yet</div>';
}
function dA(id){sA(gA().filter(a=>a.id!==id));lAppts();uSt();}

// ── Toast ───────────────────────────────────────────────────────────────────
function toast(m,t){
  const e=document.getElementById('tst');
  e.textContent=m;
  e.style.background = t==='e' ? '#ef4444' : 'var(--text)';
  e.style.color='#fff';
  e.classList.add('show'); setTimeout(()=>e.classList.remove('show'),3000);
}

// ── Init ─────────────────────────────────────────────────────────────────────
(function init(){
  // doctor select
  document.getElementById('ad').innerHTML = DOCS.map(d=>`<option value="${d.id}">${d.n} — ${d.s}</option>`).join('');
  // service select
  document.getElementById('av').innerHTML = SERVICES.map(s=>`<option>${s.n}</option>`).join('');
  // home popular services (first 4)
  document.getElementById('home-svc').innerHTML = SERVICES.slice(0,4).map(s=>svcCard(s,`pickService('${s.n.replace(/'/g,"")}')`)).join('');
  uSt();
})();
</script>
</body>
</html>"""

MANIFEST = ('{"name":"LuxeSmile Dental","short_name":"LuxeSmile","start_url":"/",'
            '"display":"standalone","background_color":"#f6f9fc","theme_color":"#0fb5a8",'
            '"icons":[{"src":"/icon-192.png","sizes":"192x192","type":"image/png"}]}')


# ── SQLite ──────────────────────────────────────────────────────────────────
def _db():
    path = os.path.join(os.path.expanduser('~'), 'luxesmile.db')
    conn = sqlite3.connect(path)
    conn.execute('''CREATE TABLE IF NOT EXISTS bookings(
        id INTEGER PRIMARY KEY, name TEXT, date TEXT, time TEXT,
        service TEXT, doctor TEXT, note TEXT, created TEXT)''')
    conn.commit()
    return conn


def _icon_bytes(name):
    """Serve icon/presplash if they sit next to main.py (used by manifest)."""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), name)
        if os.path.exists(p):
            with open(p, 'rb') as f:
                return f.read()
    except Exception:
        pass
    return None


# ── HTTP handler ──────────────────────────────────────────────────────────────
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        p = self.path.split('?')[0]
        if p in ('/', '/index.html'):
            self._ok('text/html;charset=utf-8', HTML.encode('utf-8'))
        elif p == '/manifest.json':
            self._ok('application/json', MANIFEST.encode())
        elif p in ('/icon-192.png', '/icon.png'):
            data = _icon_bytes('icon-192.png') or _icon_bytes('icon.png')
            if data: self._ok('image/png', data)
            else: self.send_response(404); self.end_headers()
        elif p == '/health':
            self._ok('application/json', b'{"ok":true}')
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length)
        if self.path == '/api/analyse':
            try:
                import base64
                d = json.loads(body)
                results, flags = analyse_image(base64.b64decode(d['image']))
                self._ok('application/json', json.dumps({'results': results, 'flags': flags}).encode())
            except Exception as e:
                self._ok('application/json', json.dumps({'results': [], 'flags': [f'Server error: {e}']}).encode())
        elif self.path == '/api/book':
            try:
                d = json.loads(body)
                c = _db()
                c.execute('INSERT INTO bookings(name,date,time,service,doctor,note,created) VALUES(?,?,?,?,?,?,?)',
                          (d.get('name', ''), d.get('date', ''), d.get('time', ''),
                           d.get('service', ''), d.get('doctor', ''), d.get('note', ''),
                           datetime.datetime.now().isoformat()))
                c.commit(); c.close()
                self._ok('application/json', b'{"ok":true}')
            except Exception as e:
                self._ok('application/json', json.dumps({'error': str(e)}).encode())
        else:
            self.send_response(404); self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def _ok(self, ct, body):
        self.send_response(200)
        self.send_header('Content-Type', ct)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


# ── Buildozer spec (creates a real .apk with the LuxeSmile icon) ────────────
def _write_spec():
    spec = """\
[app]
title              = LuxeSmile Dental
package.name       = luxesmile
package.domain     = be.luxesmile
version            = 1.0
source.dir         = .
source.include_exts = py,png,json
icon.filename      = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/presplash.png
requirements       = python3,kivy,pillow
orientation        = portrait
fullscreen         = 0
android.minapi     = 26
android.api        = 33
android.ndk        = 25b
android.archs      = arm64-v8a, armeabi-v7a
# Camera = scan, Calendar = auto-add appointments, Internet = Google Calendar link
android.permissions = INTERNET,CAMERA,READ_CALENDAR,WRITE_CALENDAR,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE

[buildozer]
log_level    = 2
warn_on_root = 1
"""
    sp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'buildozer.spec')
    if not os.path.exists(sp):
        open(sp, 'w').write(spec)
        print('OK  buildozer.spec created')


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import socket
    print('=' * 46)
    print('   LuxeSmile Dental  -  Mobile App')
    print('=' * 46)

    actual_port = PORT
    for try_port in range(PORT, PORT + 14):
        try:
            t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            t.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            t.bind(('localhost', try_port)); t.close()
            actual_port = try_port; break
        except OSError:
            continue

    socketserver.ThreadingTCPServer.allow_reuse_address = True
    srv = socketserver.ThreadingTCPServer(('localhost', actual_port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    print(f'\nOK  Server running on port {actual_port}')
    print(f'\n>>> Open Chrome  ->  http://localhost:{actual_port}')
    print('    Then  menu (:)  ->  "Add to Home screen"  for the LuxeSmile icon.\n')

    _write_spec()

    # In Pydroid, optionally auto-open the browser
    try:
        import webbrowser
        webbrowser.open(f'http://localhost:{actual_port}')
    except Exception:
        pass

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print('\nStopped.')
        srv.shutdown()
