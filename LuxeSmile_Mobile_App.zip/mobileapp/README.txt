==========================================================
  LuxeSmile Dental — Mobile App
==========================================================

This is the LuxeSmile experience packaged for Android: AI teeth scan
(with a front/back camera switch), appointment booking, services,
doctors and contact — styled like your v31 website. When you confirm a
booking, the reservation is added straight to your phone calendar.

Files in this folder:
  main.py          the whole app (server + mobile UI in one file)
  icon.png         app icon (LuxeSmile tooth) — 512x512
  icon-192.png     small icon used by the web manifest
  presplash.png    splash screen shown while the app starts
  buildozer.spec   build config for making the .apk
  README.txt       this file


----------------------------------------------------------
 OPTION A — Run instantly on your phone (Pydroid 3)
----------------------------------------------------------
No build needed. Good for testing today.

  1. Install "Pydroid 3" from the Play Store.
  2. In Pydroid: open the pip menu (left drawer) and install:  pillow
  3. Copy main.py (and icon files) into Pydroid, open main.py, tap  Run (▶).
  4. It prints a link like  http://localhost:8766
     Open that in Chrome on the same phone.
  5. In Chrome: menu (⋮) -> "Add to Home screen".
     You now get a LuxeSmile icon that opens the app full-screen.

Camera + calendar work in Chrome. Allow the camera/permission prompts.


----------------------------------------------------------
 OPTION B — Build a real installable app (.apk)
----------------------------------------------------------
This produces a normal Android app with the LuxeSmile icon that opens
when you tap it. Build on Linux (or WSL2 on Windows).

  1. Install Buildozer once:
        pip install buildozer cython
        # plus the usual Android build deps (openjdk, etc.)
  2. Keep all files in this folder together (main.py, icon.png,
     presplash.png, buildozer.spec).
  3. Build:
        buildozer android debug
  4. The .apk appears in the  bin/  folder.
     Copy it to your phone and install (allow "unknown sources").
  5. Tap the LuxeSmile icon — the app opens.

(First build downloads the Android SDK/NDK and takes a while. Later
 builds are fast.)


----------------------------------------------------------
 How the camera works
----------------------------------------------------------
- Scan tab -> "Start Camera". It starts on the BACK camera.
- The 🔄 button flips between BACK and FRONT camera at any time.
- A small badge shows which camera is active.
- "Take Photo" -> "Analyse with AI" runs the colour/edge analysis
  (brightness grade, yellowness, edge sharpness, per-tooth grades).


----------------------------------------------------------
 How the calendar works
----------------------------------------------------------
When you tap "Confirm Booking":
  - The appointment is saved in the app (My Appointments) and the
    server database.
  - Google Calendar opens automatically, pre-filled with the date,
    time, doctor, service and clinic address — tap Save and it's in
    your calendar.
  - For Samsung Calendar / other calendar apps (or offline), use the
    "⬇ Add via .ics" button — opening that file adds the event to the
    phone's default calendar app.
  - Every saved appointment has its own "📅 Calendar" and "⬇ .ics"
    buttons so you can re-add it anytime.

Tip: the event includes a 2-hour reminder alarm.


----------------------------------------------------------
 Customising
----------------------------------------------------------
- Clinic address / phone / email: edit the CONTACT section and the
  CLINIC constant in main.py.
- Services & prices: edit the SERVICES list in main.py.
- Doctors: edit the DOCS list in main.py.
- App name / package id: edit buildozer.spec ([app] title / package.name).
- Icon: replace icon.png (512x512) and presplash.png.
