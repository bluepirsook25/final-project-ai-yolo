[app]
title              = LuxeSmile Dental
package.name       = luxesmile
package.domain     = be.luxesmile
version            = 1.0
source.dir         = .
source.include_exts = py,png,json
icon.filename      = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/presplash.png
requirements       = python3,kivy,pillow
orientation        = portrait
fullscreen         = 0
android.minapi     = 26
android.api        = 33
android.ndk        = 25b
android.archs      = arm64-v8a, armeabi-v7a
# Camera = scan, Calendar = auto-add appointments, Internet = Google Calendar link
android.permissions = INTERNET,CAMERA,READ_CALENDAR,WRITE_CALENDAR,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE

[buildozer]
log_level    = 2
warn_on_root = 1
